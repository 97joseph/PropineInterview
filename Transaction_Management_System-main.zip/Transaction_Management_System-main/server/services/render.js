exports.homeRoutes = (req, res) => {
  res.render('index');
}